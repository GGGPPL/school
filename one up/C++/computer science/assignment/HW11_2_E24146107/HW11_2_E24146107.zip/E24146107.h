#ifndef E24146107_H  // 記得改成你的學號_H
#define E24146107_H  // 記得改成你的學號_H

#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

// 請將類別名稱修改為你的學號 (例如 class E24131234)
class E24146107 {
public:
    // 判斷是否為合法的一步 (欄位在 0-6 之間，且該欄最上方是空的)
    bool isValid(const int board[6][7], int col) {
        if (col < 0 || col > 6) return false;
        return board[0][col] == 0;
    }

    // 檢查某個玩家是否快贏了 (已經有3子連線，且第4個位置是空的)
    // 如果 found，回傳那個致勝/防守的 column，否則回傳 -1
    int findWinningMove(const int board[6][7], int player) {
        // 模擬下在每一個 column
        for (int c = 0; c < 7; c++) {
            if (!isValid(board, c)) continue;

            // 暫時模擬下子
            int r = 5;
            while (r >= 0 && board[r][c] != 0) r--; // 找到落點
            if (r < 0) continue;

            // 檢查是否因為這步而獲勝 (這裡簡化檢查邏輯)
            // 由於不能真的修改 const board，我們手動檢查落點 r, c 附近的連線
            if (checkConnection(board, r, c, player)) {
                return c;
            }
        }
        return -1;
    }

    // 輔助函式：檢查在 (r, c) 下了 player 的棋子後是否連成4線
    bool checkConnection(const int board[6][7], int r, int c, int player) {
        // 方向：水平、垂直、左斜、右斜
        int dr[] = {0, 1, 1, 1};
        int dc[] = {1, 0, 1, -1};

        for (int d = 0; d < 4; d++) {
            int count = 1; // 包含自己
            // 正向檢查
            for (int k = 1; k < 4; k++) {
                int nr = r + dr[d] * k;
                int nc = c + dc[d] * k;
                if (nr < 0 || nr >= 6 || nc < 0 || nc >= 7 || board[nr][nc] != player) break;
                count++;
            }
            // 反向檢查
            for (int k = 1; k < 4; k++) {
                int nr = r - dr[d] * k;
                int nc = c - dc[d] * k;
                if (nr < 0 || nr >= 6 || nc < 0 || nc >= 7 || board[nr][nc] != player) break;
                count++;
            }
            if (count >= 4) return true;
        }
        return false;
    }

    // 主策略函式
    // board: 0=空, 1=玩家1, 2=玩家2
    // turn: 代表你是 1 還是 2
    int strategy(const int board[6][7], int turn) {
        int opponent = (turn == 1) ? 2 : 1;

        // 1. 進攻：如果我能贏，直接贏
        int winMove = findWinningMove(board, turn);
        if (winMove != -1) return winMove;

        // 2. 防守：如果對手下一手會贏，擋住他
        int blockMove = findWinningMove(board, opponent);
        if (blockMove != -1) return blockMove;

        // 3. 策略：優先佔領中間，順序為 [3, 2, 4, 1, 5, 0, 6]
        int priorityCols[] = {3, 2, 4, 1, 5, 0, 6};
        for (int i = 0; i < 7; i++) {
            int col = priorityCols[i];
            if (isValid(board, col)) {
                return col;
            }
        }

        // 4. 如果都滿了(理論上不會發生)，隨便回傳一個合法的
        for (int i = 0; i < 7; i++) {
            if (isValid(board, i)) return i;
        }

        return 0; // Fallback
    }
};

#endif